import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-notfound',
  templateUrl: './notfound.component.html',
  styleUrls: ['./notfound.component.css']
})
export class NotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
