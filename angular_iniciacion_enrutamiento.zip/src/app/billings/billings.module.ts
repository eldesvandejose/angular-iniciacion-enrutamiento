import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BillingsRoutingModule } from './billings-routing.module';

@NgModule({
  imports: [
    CommonModule,
    BillingsRoutingModule
  ],
  declarations: []
})
export class BillingsModule { }
