import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-supplier-request',
  templateUrl: './supplier-request.component.html',
  styleUrls: ['./supplier-request.component.css']
})
export class SupplierRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
