import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './commons/home/home.component';
import { CustomersListComponent } from './customers/customers-list/customers-list.component';
import { SuppliersListComponent } from './suppliers/suppliers-list/suppliers-list.component';
import { NotfoundComponent } from './commons/notfound/notfound.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'clientes',
    component: CustomersListComponent
  },
  {
    path: 'proveedores',
    component: SuppliersListComponent
  },
  {
    path: '**',
    component: NotfoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
